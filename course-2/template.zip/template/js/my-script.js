getSongs('Let it go')

 whenSongsReadyDo(
   function(){
     var mySongs = getSongTitlesAndArtists()
     displaySongsList(mySongs)
     setupPlayer()
   }
 )